CREATE PROCEDURE create_indexes(IN Given VARCHAR(20))
  BEGIN
 
 DECLARE IndexIsThere INTEGER; 
 SELECT COUNT(1) INTO IndexIsThere FROM information_schema.statistics
 WHERE TABLE_SCHEMA = DATABASE()
 AND TABLE_NAME = 'work_days'
 AND INDEX_NAME = 'work_date_iterations'; IF IndexIsThere = 0 THEN
 /* составной индекс по дате и итерациям */
 CREATE INDEX  work_date_iterations  ON work_days(work_date, iterations); 
 END IF; 
 SELECT COUNT(1) INTO IndexIsThere FROM information_schema.statistics
 WHERE TABLE_SCHEMA = DATABASE()
 AND TABLE_NAME = 'work_iters'
 AND INDEX_NAME = 'ddate'; IF IndexIsThere = 0 THEN
 /* индекс по дате */
 CREATE INDEX ddate ON work_iters(ddate); 
 END IF; END;
